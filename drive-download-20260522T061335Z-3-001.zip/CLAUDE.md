﻿# CLAUDE.md — NETA AI
# Extends ~/.claude/CLAUDE.md.

## Stack
Python 3.11, FastAPI, PostgreSQL (PostGIS), Redis, Docker, Celery

## Current Phase: 1

## Module Boundaries
  Session → database-design	: app\database-design only
  Session → security-auth	: app\security-auth only
  Session → geojson-mapping	: app\geojson-mapping only
  Session → ground-operations	: app\ground-operations only
  Session → news-intelligence	: app\news-intelligence only
  Session → booth-management	: app\booth-management only
  Session → prediction-sentiment	: app\prediction-sentiment only
  Session → opposition-intelligence	: app\opposition-intelligence only
  Session → whatsapp-integration	: app\whatsapp-integration only
  Session → devops-deployment	: app\devops-deployment only
  Session → debug   : one error + one file per session

## Key Config
  DATABASE_URL=postgresql+asyncpg://netaai_app:netaai_password@localhost:5432/netaai_prod
  REDIS_URL=redis://:redis_password@localhost:6379/0
  JWT_ALGORITHM=HS256
  ACCESS_TOKEN_EXPIRE_MINUTES=15
  NLP_MODEL_PATH=/models/indic-bert-political

## Git
  main / dev / feature/TASK-XXX
  Format: [TASK-XXX] verb: what changed
