﻿# TOOLS.md — NETA AI

## Plugins: superpowers, context7, code-simplifier, context-mode
## MCPs: filesystem, memory, sequential-thinking

## Session Launcher
  .\neta-sessions.ps1 -Session list

## Test Commands
  pytest tests/
