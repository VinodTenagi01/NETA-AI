﻿# SKILLS.md — NETA AI

| Command      | File                          | What it does                  |
|--------------|-------------------------------|-------------------------------|
| task-create  | .claude/skills/task-create.md | Create a new TASK-XXX.md      |
